import React, { useState, useEffect } from 'react';
import { 
  Eye, 
  ShieldCheck, 
  Search, 
  Menu, 
  X, 
  ArrowRight, 
  CheckCircle,
  ShoppingBag, 
  User,        
  Camera,
  Music,
  Paintbrush,
  MapPin,
  Wrench,
  Users,
  Sparkles,
  Code,
  Milk,
  Leaf,
  Calendar,
  Package,
  Star,
  Award,
  Crown,
  ChevronRight,
  Globe,
  Briefcase
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- WINE MASTERS DATA ---
const MASTERS_DATA = [
  {
    id: 1,
    name: "Alessandro Rossi",
    title: "Cinematic Storyteller",
    category: "Cinematography",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=800&auto=format&fit=crop",
    rate: "₹25,000",
    period: "day",
    description: "Award-winning cinematographer specializing in luxury weddings and commercial productions.",
    verified: true,
    featured: true
  },
  {
    id: 2,
    name: "Priya Mehta",
    title: "Visual Artist",
    category: "Photography",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?q=80&w=800&auto=format&fit=crop",
    rate: "₹18,000",
    period: "session",
    description: "Fine art photographer capturing timeless moments with editorial elegance.",
    verified: true,
    featured: true
  },
  {
    id: 3,
    name: "Aria Collective",
    title: "Symphony Ensemble",
    category: "Music & Bands",
    image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=800&auto=format&fit=crop",
    rate: "₹75,000",
    period: "event",
    description: "Elite musical ensemble for prestigious events and celebrations.",
    verified: true,
    featured: true
  },
  {
    id: 4,
    name: "Kavya Iyer",
    title: "Contemporary Artist",
    category: "Artists & Designers",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?q=80&w=800&auto=format&fit=crop",
    rate: "₹1,200",
    period: "sq.ft",
    description: "Bespoke art installations and murals for discerning collectors.",
    verified: true,
    featured: false
  },
  {
    id: 5,
    name: "Marco Traveler",
    title: "Cultural Curator",
    category: "Local Guides",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?q=80&w=800&auto=format&fit=crop",
    rate: "₹5,000",
    period: "experience",
    description: "Exclusive heritage tours curated for sophisticated travelers.",
    verified: true,
    featured: false
  },
  {
    id: 6,
    name: "Maison Events",
    title: "Experience Designer",
    category: "Event Planners",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=800&auto=format&fit=crop",
    rate: "₹2,50,000",
    period: "event",
    description: "Orchestrating unforgettable celebrations with impeccable attention to detail.",
    verified: true,
    featured: true
  },
  {
    id: 7,
    name: "Digital Atelier",
    title: "Innovation Studio",
    category: "Tech Services",
    image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&auto=format&fit=crop",
    rate: "₹50,000",
    period: "project",
    description: "Crafting digital experiences that merge technology with artistry.",
    verified: true,
    featured: false
  },
  {
    id: 8,
    name: "Artisan Build",
    title: "Master Craftsman",
    category: "Contractors",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=800&auto=format&fit=crop",
    rate: "₹1,500",
    period: "sq.ft",
    description: "Exquisite architectural renovations with old-world craftsmanship.",
    verified: true,
    featured: false
  },
  {
    id: 9,
    name: "La Latteria",
    title: "Artisanal Dairy",
    category: "Fresh Dairy",
    image: "https://images.unsplash.com/photo-1550583724-b2692b85b150?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1563636619-e9143da7973b?q=80&w=800&auto=format&fit=crop",
    rate: "₹3,500",
    period: "month",
    subscriptionModel: true,
    dailyQuantity: "1L daily",
    description: "Premium A2 milk from heritage breeds, delivered at dawn.",
    verified: true,
    featured: false
  },
  {
    id: 10,
    name: "Terra Organica",
    title: "Organic Cultivator",
    category: "Organic Farmers",
    image: "https://images.unsplash.com/photo-1592982537447-7440770cbfc9?q=80&w=800&auto=format&fit=crop",
    workSample: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?q=80&w=800&auto=format&fit=crop",
    rate: "₹2,500",
    period: "basket",
    marketplace: true,
    description: "Biodynamic farm producing exceptional organic produce, farm to table.",
    verified: true,
    featured: true
  }
];

const GENRES = [
  { name: "Cinematography", icon: Camera },
  { name: "Photography", icon: Eye },
  { name: "Music & Bands", icon: Music },
  { name: "Artists & Designers", icon: Paintbrush },
  { name: "Local Guides", icon: MapPin },
  { name: "Event Planners", icon: Sparkles },
  { name: "Tech Services", icon: Code },
  { name: "Contractors", icon: Wrench },
  { name: "Fresh Dairy", icon: Milk },
  { name: "Organic Farmers", icon: Leaf }
];

// --- WINE LOGO COMPONENT ---
const BoyinwinLogo = ({ white = false }: { white?: boolean }) => (
  <svg viewBox="0 0 240 100" className="w-full h-full">
    <defs>
      <linearGradient id="wineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#8B0000" />
        <stop offset="100%" stopColor="#4A0E0E" />
      </linearGradient>
    </defs>
    
    {/* Main Stamp Circle */}
    <g transform="translate(10, 5)">
      {/* Outer Circle Border */}
      <circle 
        cx="45" 
        cy="45" 
        r="42" 
        fill="none" 
        stroke={white ? "#fff" : "#8B0000"} 
        strokeWidth="2.5"
        opacity={white ? "0.95" : "1"}
      />
      
      {/* Inner Circle Border */}
      <circle 
        cx="45" 
        cy="45" 
        r="37" 
        fill="none" 
        stroke={white ? "#fff" : "#8B0000"} 
        strokeWidth="1"
        opacity={white ? "0.7" : "0.85"}
      />
      
      {/* Top Arc Text - BOYINWIN */}
      <path 
        id="topArc" 
        d="M 12,45 A 33,33 0 0,1 78,45" 
        fill="none"
      />
      <text fontFamily="serif" fontSize="11" letterSpacing="3" fill={white ? "#fff" : "#8B0000"} fontWeight="700">
        <textPath href="#topArc" startOffset="50%" textAnchor="middle">
          BOYINWIN
        </textPath>
      </text>
      
      {/* Center Wine Glass */}
      <g transform="translate(30, 28)">
        <path 
          d="M 15 8 Q 10 8 10 16 L 12 26 Q 15 30 18 30 Q 21 30 24 26 L 26 16 Q 26 8 21 8 Z" 
          fill={white ? "#fff" : "url(#wineGrad)"}
          opacity={white ? "0.95" : "1"}
        />
        <rect x="17" y="30" width="2" height="10" fill={white ? "#fff" : "#8B0000"} />
        <ellipse cx="18" cy="41" rx="5" ry="2" fill={white ? "#fff" : "#8B0000"} />
        <ellipse cx="18" cy="18" rx="6" ry="2.5" fill={white ? "rgba(255,255,255,0.5)" : "#6B0F1A"} opacity="0.85" />
      </g>
      
      {/* Bottom Arc Text - TALENT VINEYARD */}
      <path 
        id="bottomArc" 
        d="M 12,45 A 33,33 0 0,0 78,45" 
        fill="none"
      />
      <text fontFamily="serif" fontSize="7" letterSpacing="2" fill={white ? "rgba(255,255,255,0.75)" : "#8B0000"} opacity="0.9" fontStyle="italic">
        <textPath href="#bottomArc" startOffset="50%" textAnchor="middle">
          TALENT VINEYARD
        </textPath>
      </text>
      
      {/* Decorative Stars */}
      <circle cx="8" cy="45" r="2" fill={white ? "#fff" : "#8B0000"} opacity="0.7" />
      <circle cx="82" cy="45" r="2" fill={white ? "#fff" : "#8B0000"} opacity="0.7" />
      
      {/* Top Star */}
      <circle cx="45" cy="8" r="1.5" fill={white ? "#fff" : "#8B0000"} opacity="0.6" />
      
      {/* Bottom Star */}
      <circle cx="45" cy="82" r="1.5" fill={white ? "#fff" : "#8B0000"} opacity="0.6" />
    </g>
    
    {/* Full Name Wordmark - BOYINWIN */}
    <text 
      x="110" 
      y="45" 
      fontFamily="serif" 
      fontSize="28" 
      letterSpacing="10"
      fill={white ? "#fff" : "#000"}
      fontWeight="400"
    >
      BOYINWIN
    </text>
    
    {/* Subtitle */}
    <text 
      x="111" 
      y="65" 
      fontFamily="serif" 
      fontSize="8" 
      letterSpacing="3"
      fill={white ? "rgba(255,255,255,0.75)" : "#8B0000"}
      fontStyle="italic"
    >
      EST. 2024 • HIMALAYA
    </text>
    
    {/* Decorative Elements */}
    <circle cx="107" cy="61" r="1" fill={white ? "rgba(255,255,255,0.5)" : "#8B0000"} opacity="0.6" />
    <circle cx="233" cy="61" r="1" fill={white ? "rgba(255,255,255,0.5)" : "#8B0000"} opacity="0.6" />
  </svg>
);

// --- NAVIGATION ---
const NavBar = ({ setView, openCart, openLogin }: any) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${
      isScrolled 
        ? 'bg-black/95 backdrop-blur-xl border-b border-white/10' 
        : 'bg-black/80 backdrop-blur-md'
    }`}>
      <div className="max-w-7xl mx-auto px-8 lg:px-12">
        <div className="flex items-center justify-between h-24">
          
          <button className="outline-none hover:opacity-80 transition-opacity w-40" onClick={() => setView('home')}>
            <BoyinwinLogo white />
          </button>

          <div className="hidden lg:flex items-center gap-16">
            <button onClick={() => setView('portal')} className="text-sm tracking-[0.3em] text-white/80 hover:text-white transition-colors uppercase">
              Vineyard
            </button>
            <button onClick={() => setView('client-form')} className="text-sm tracking-[0.3em] text-white/80 hover:text-white transition-colors uppercase">
              Reserve
            </button>
            <button onClick={() => setView('artist-form')} className="text-sm tracking-[0.3em] text-white/80 hover:text-white transition-colors uppercase">
              Join
            </button>
          </div>

          <div className="flex items-center gap-8">
            <button onClick={openCart} className="relative text-white/80 hover:text-white transition-colors">
              <ShoppingBag className="w-5 h-5" strokeWidth={1.5} />
            </button>
            <button onClick={openLogin} className="text-sm tracking-[0.3em] text-white/80 hover:text-white transition-colors uppercase hidden sm:block">
              Sign In
            </button>
            <div className="lg:hidden">
              <Menu className="w-5 h-5 text-white" strokeWidth={1.5} />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

// --- HERO SECTION ---
const Hero = ({ setView }: any) => (
  <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
    {/* Himalayan Vineyard Background */}
    <div className="absolute inset-0">
      <img 
        src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2400&auto=format&fit=crop" 
        alt="Himalayan Mountains" 
        className="w-full h-full object-cover opacity-40"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90"></div>
      
      {/* Wine Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#8B0000]/20 via-transparent to-[#4A0E0E]/20"></div>
    </div>
    
    <div className="relative z-10 text-center px-4 max-w-6xl mx-auto pt-20">
      <motion.div 
        initial={{ opacity: 0, y: 40 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 1.2, ease: "easeOut" }}
      >
        {/* Badge */}
        <div className="inline-flex items-center gap-3 border-2 border-white/20 px-8 py-3 mb-16 bg-white/5 backdrop-blur-sm">
          <Globe className="w-4 h-4 text-[#8B0000]" strokeWidth={1.5} />
          <span className="text-xs tracking-[0.4em] text-white uppercase">Himalayan Workspace</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-7xl md:text-9xl text-white mb-10 tracking-tighter leading-none" style={{ fontFamily: 'serif' }}>
          Where Talent<br />
          <span className="text-[#8B0000] italic">Ferments</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-white/70 mb-20 max-w-3xl mx-auto tracking-wide leading-relaxed">
          A premium collective of artisans cultivated at altitude. From vineyard to workspace.
        </p>
        
        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center mb-28">
          <button 
            onClick={() => setView('portal')}
            className="group relative bg-[#8B0000] text-white px-14 py-6 overflow-hidden transition-all duration-500 hover:bg-[#6B0F1A]"
          >
            <span className="relative z-10 text-sm tracking-[0.3em] uppercase flex items-center justify-center gap-3">
              Enter Vineyard
              <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" strokeWidth={1.5} />
            </span>
          </button>
          
          <button 
            onClick={() => setView('client-form')}
            className="border-2 border-white text-white px-14 py-6 hover:bg-white hover:text-black transition-all duration-500"
          >
            <span className="text-sm tracking-[0.3em] uppercase">Make Reservation</span>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-16 max-w-4xl mx-auto pt-16 border-t border-white/10">
          <div>
            <div className="text-5xl text-[#8B0000] mb-3" style={{ fontFamily: 'serif' }}>10</div>
            <div className="text-xs tracking-[0.3em] text-white/50 uppercase">Vintages</div>
          </div>
          <div>
            <div className="text-5xl text-white mb-3" style={{ fontFamily: 'serif' }}>5K+</div>
            <div className="text-xs tracking-[0.3em] text-white/50 uppercase">Artisans</div>
          </div>
          <div>
            <div className="text-5xl text-[#8B0000] mb-3" style={{ fontFamily: 'serif' }}>∞</div>
            <div className="text-xs tracking-[0.3em] text-white/50 uppercase">Altitude</div>
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

// --- PORTAL VIEW ---
const PortalView = ({ setMaster }: any) => {
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  
  const filteredMasters = selectedGenre 
    ? MASTERS_DATA.filter(m => m.category === selectedGenre)
    : MASTERS_DATA;
  
  const featuredMasters = MASTERS_DATA.filter(m => m.featured);
  
  return (
    <div className="bg-black min-h-screen pt-32 pb-32 px-4 sm:px-8">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5">
        <img 
          src="https://images.unsplash.com/photo-1560493676-04071c5f467b?q=80&w=2400&auto=format&fit=crop" 
          alt="" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Featured Section */}
        {!selectedGenre && (
          <div className="mb-40">
            <div className="text-center mb-20">
              <div className="inline-block border-b-2 border-[#8B0000] pb-4 mb-8">
                <h2 className="text-6xl text-white" style={{ fontFamily: 'serif' }}>Reserve Collection</h2>
              </div>
              <p className="text-white/50 tracking-[0.2em] uppercase text-sm">Aged to Perfection</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {featuredMasters.map((master, idx) => (
                <motion.div
                  key={master.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: idx * 0.1 }}
                  whileHover={{ y: -12 }}
                  className="group cursor-pointer"
                  onClick={() => setMaster(master)}
                >
                  <div className="relative h-[500px] mb-8 overflow-hidden bg-white/5 border-2 border-white/10 hover:border-[#8B0000] transition-all duration-500">
                    <img 
                      src={master.image} 
                      alt={master.name} 
                      className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
                    
                    {/* Badge */}
                    <div className="absolute top-6 right-6">
                      <div className="bg-[#8B0000] text-white px-4 py-2 flex items-center gap-2">
                        <Star className="w-3 h-3" strokeWidth={1.5} fill="currentColor" />
                        <span className="text-[9px] tracking-[0.3em] uppercase">Reserve</span>
                      </div>
                    </div>
                    
                    {/* Hover Overlay */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <div className="text-white text-sm tracking-[0.3em] uppercase flex items-center gap-3">
                        View Master
                        <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-[10px] tracking-[0.3em] text-[#8B0000] uppercase mb-3">{master.category}</div>
                  <h3 className="text-3xl text-white mb-2 group-hover:text-[#8B0000] transition-colors" style={{ fontFamily: 'serif' }}>{master.name}</h3>
                  <p className="text-white/60 mb-4 tracking-wide">{master.title}</p>
                  <div className="flex items-baseline gap-3 pt-4 border-t border-white/10">
                    <span className="text-2xl text-white" style={{ fontFamily: 'serif' }}>₹{master.rate.replace('₹', '')}</span>
                    <span className="text-sm text-white/40">/ {master.period}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Categories */}
        <div className="mb-24">
          <div className="text-center mb-16">
            <div className="inline-block border-b-2 border-white/20 pb-4">
              <h2 className="text-5xl text-white" style={{ fontFamily: 'serif' }}>The Vineyard</h2>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-10 gap-4">
            {GENRES.map((genre) => {
              const Icon = genre.icon;
              const isSelected = selectedGenre === genre.name;
              return (
                <button
                  key={genre.name}
                  onClick={() => setSelectedGenre(isSelected ? null : genre.name)}
                  className={`group p-8 border-2 transition-all duration-300 ${
                    isSelected
                      ? 'border-[#8B0000] bg-[#8B0000] text-white'
                      : 'border-white/10 hover:border-white/30 bg-white/5'
                  }`}
                >
                  <Icon className={`w-6 h-6 mx-auto mb-4 transition-colors ${isSelected ? 'text-white' : 'text-white/60 group-hover:text-white'}`} strokeWidth={1.5} />
                  <div className={`text-[9px] tracking-[0.2em] uppercase text-center leading-tight ${isSelected ? 'text-white' : 'text-white/60 group-hover:text-white'}`}>
                    {genre.name.replace(' & ', ' ')}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filtered Masters */}
        {selectedGenre && (
          <div>
            <div className="flex items-center justify-between mb-16 pb-8 border-b border-white/10">
              <h3 className="text-4xl text-white" style={{ fontFamily: 'serif' }}>{selectedGenre}</h3>
              <button onClick={() => setSelectedGenre(null)} className="text-sm text-white/50 hover:text-white tracking-[0.2em] uppercase transition-colors">
                Clear
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-10">
              {filteredMasters.map((master) => (
                <motion.div
                  key={master.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="group cursor-pointer"
                  onClick={() => setMaster(master)}
                >
                  <div className="relative h-96 mb-6 overflow-hidden bg-white/5 border border-white/10 hover:border-[#8B0000] transition-all duration-500">
                    <img 
                      src={master.image} 
                      alt={master.name} 
                      className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-all"></div>
                  </div>
                  
                  <div className="text-[9px] tracking-[0.3em] text-[#8B0000] uppercase mb-2">{master.category}</div>
                  <h4 className="text-xl text-white mb-2 group-hover:text-[#8B0000] transition-colors" style={{ fontFamily: 'serif' }}>{master.name}</h4>
                  <p className="text-sm text-white/50 mb-3">{master.title}</p>
                  <div className="text-white" style={{ fontFamily: 'serif' }}>
                    ₹{master.rate.replace('₹', '')} <span className="text-xs text-white/40">/ {master.period}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

// --- MASTER DETAIL ---
const MasterDetail = ({ master, onClose, onHire }: any) => {
  if (!master) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/98 backdrop-blur-xl overflow-y-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-black border-2 border-white/10 w-full max-w-7xl relative"
      >
        <button onClick={onClose} className="absolute top-8 right-8 z-10 text-white/60 hover:text-white transition-colors">
          <X className="w-7 h-7" strokeWidth={1.5} />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2">
          {/* Image */}
          <div className="relative h-[70vh] lg:h-auto">
            <img src={master.image} alt={master.name} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/60 lg:to-black/80"></div>
            
            {master.featured && (
              <div className="absolute top-8 left-8">
                <div className="bg-[#8B0000] text-white px-5 py-3 flex items-center gap-2">
                  <Star className="w-4 h-4" strokeWidth={1.5} fill="currentColor" />
                  <span className="text-xs tracking-[0.3em] uppercase">Reserve Collection</span>
                </div>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-16 lg:p-20 flex flex-col justify-center bg-black">
            <div className="text-[10px] tracking-[0.4em] text-[#8B0000] uppercase mb-4">{master.category}</div>
            <h2 className="text-6xl text-white mb-4 leading-tight" style={{ fontFamily: 'serif' }}>{master.name}</h2>
            <p className="text-2xl text-white/60 mb-12 tracking-wide">{master.title}</p>

            <div className="mb-12">
              <h3 className="text-sm tracking-[0.3em] text-white/50 uppercase mb-6">Biography</h3>
              <p className="text-white/80 leading-relaxed text-lg">{master.description}</p>
            </div>

            {master.dailyQuantity && (
              <div className="border-2 border-white/10 p-6 mb-12">
                <div className="flex items-center gap-4 text-white">
                  <Milk className="w-6 h-6" strokeWidth={1.5} />
                  <span className="tracking-wide text-lg">Daily: {master.dailyQuantity}</span>
                </div>
              </div>
            )}

            <div className="border-t-2 border-white/10 pt-10 mb-12">
              <div className="flex justify-between items-baseline">
                <span className="text-sm tracking-[0.3em] text-white/40 uppercase">
                  {master.subscriptionModel ? 'Monthly' : master.marketplace ? 'Per Basket' : 'Rate'}
                </span>
                <div className="text-right">
                  <span className="text-5xl text-white" style={{ fontFamily: 'serif' }}>₹{master.rate.replace('₹', '')}</span>
                  <span className="text-white/40 ml-3 text-lg">/ {master.period}</span>
                </div>
              </div>
            </div>

            <button 
              onClick={() => onHire(master)}
              className="w-full bg-[#8B0000] text-white py-6 hover:bg-[#6B0F1A] transition-all duration-500 group"
            >
              <span className="text-sm tracking-[0.3em] uppercase flex items-center justify-center gap-4">
                {master.subscriptionModel ? 'Subscribe Now' : master.marketplace ? 'Order Now' : 'Reserve Now'}
                <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" strokeWidth={1.5} />
              </span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// --- FORMS ---
const FormLayout = ({ title, subtitle, children, onClose }: any) => (
  <div className="min-h-screen bg-black pt-32 pb-24 px-4 flex justify-center items-start">
    {/* Background */}
    <div className="fixed inset-0 opacity-10">
      <img 
        src="https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=2400&auto=format&fit=crop" 
        alt="" 
        className="w-full h-full object-cover"
      />
    </div>
    
    <div className="w-full max-w-3xl relative z-10">
      <div className="flex justify-between items-start mb-16">
        <div>
          <h2 className="text-6xl text-white mb-4 leading-tight" style={{ fontFamily: 'serif' }}>{title}</h2>
          <p className="text-white/50 tracking-[0.2em] uppercase text-sm">{subtitle}</p>
        </div>
        <button onClick={onClose} className="text-white/50 hover:text-white transition-colors">
          <X className="w-7 h-7" strokeWidth={1.5} />
        </button>
      </div>
      {children}
    </div>
  </div>
);

const ClientForm = ({ onClose }: any) => (
  <FormLayout title="Reservation" subtitle="Begin Your Journey" onClose={onClose}>
    <form className="space-y-10">
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Project Vision</label>
        <input 
          type="text" 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30" 
          placeholder="Describe your needs"
        />
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Vintage Selection</label>
        <select className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors">
          <option className="bg-black">Select Category</option>
          {GENRES.map(g => <option key={g.name} className="bg-black">{g.name}</option>)}
        </select>
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Investment Range</label>
        <input 
          type="text" 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30" 
          placeholder="Budget allocation"
        />
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Additional Details</label>
        <textarea 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors h-40 resize-none placeholder:text-white/30" 
          placeholder="Share your vision..."
        ></textarea>
      </div>
      
      <button 
        type="button" 
        className="w-full bg-[#8B0000] text-white py-7 hover:bg-[#6B0F1A] transition-all duration-500 mt-12"
      >
        <span className="text-sm tracking-[0.3em] uppercase">Submit Reservation</span>
      </button>
    </form>
  </FormLayout>
);

const ArtistForm = ({ onClose }: any) => (
  <FormLayout title="Join Vineyard" subtitle="Become A Master" onClose={onClose}>
    <form className="space-y-10">
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Full Name</label>
        <input 
          type="text" 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30" 
          placeholder="Your name"
        />
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Craft</label>
        <select className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors">
          <option className="bg-black">Select expertise</option>
          {GENRES.map(g => <option key={g.name} className="bg-black">{g.name}</option>)}
        </select>
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Rate</label>
        <input 
          type="text" 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30" 
          placeholder="Your rate"
        />
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Portfolio</label>
        <input 
          type="url" 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30" 
          placeholder="Link to work"
        />
      </div>
      
      <div>
        <label className="block text-xs tracking-[0.3em] text-white/50 uppercase mb-4">Biography</label>
        <textarea 
          className="w-full bg-transparent border-b-2 border-white/20 p-5 text-white text-lg focus:border-[#8B0000] outline-none transition-colors h-40 resize-none placeholder:text-white/30" 
          placeholder="Your story..."
        ></textarea>
      </div>
      
      <button 
        type="button" 
        className="w-full bg-[#8B0000] text-white py-7 hover:bg-[#6B0F1A] transition-all duration-500 mt-12"
      >
        <span className="text-sm tracking-[0.3em] uppercase">Apply to Vineyard</span>
      </button>
    </form>
  </FormLayout>
);

const LoginModal = ({ isOpen, onClose }: any) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/98 backdrop-blur-xl">
        <motion.div 
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-black border-2 border-white/10 w-full max-w-md p-16 relative"
        >
          <button onClick={onClose} className="absolute top-6 right-6 text-white/50 hover:text-white">
            <X strokeWidth={1.5} />
          </button>
          
          <div className="text-center mb-12">
            <div className="w-32 mx-auto mb-8">
              <BoyinwinLogo white />
            </div>
            <h2 className="text-4xl text-white mb-3" style={{ fontFamily: 'serif' }}>Welcome</h2>
            <p className="text-white/50 text-sm tracking-[0.2em] uppercase">Access Vineyard</p>
          </div>
          
          <form className="space-y-8">
            <input 
              type="email" 
              placeholder="Email" 
              className="w-full bg-transparent border-b-2 border-white/20 p-4 text-white focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30"
            />
            <input 
              type="password" 
              placeholder="Password" 
              className="w-full bg-transparent border-b-2 border-white/20 p-4 text-white focus:border-[#8B0000] outline-none transition-colors placeholder:text-white/30"
            />
            <button className="w-full bg-[#8B0000] text-white py-5 hover:bg-[#6B0F1A] transition-all duration-500 mt-8">
              <span className="text-xs tracking-[0.3em] uppercase">Sign In</span>
            </button>
          </form>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

const CartDrawer = ({ isOpen, onClose }: any) => (
  <AnimatePresence>
    {isOpen && (
      <>
        <div className="fixed inset-0 bg-black/90 z-[70]" onClick={onClose}></div>
        <motion.div 
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: "spring", damping: 30, stiffness: 300 }}
          className="fixed right-0 top-0 h-full w-full max-w-lg bg-black border-l-2 border-white/10 z-[80] p-10"
        >
          <div className="flex justify-between items-center mb-16">
            <h2 className="text-3xl text-white" style={{ fontFamily: 'serif' }}>Cart</h2>
            <button onClick={onClose}>
              <X className="text-white/50 hover:text-white" strokeWidth={1.5} />
            </button>
          </div>
          
          <div className="flex flex-col h-full justify-center items-center text-white/30 pb-20">
            <ShoppingBag className="w-16 h-16 mb-6" strokeWidth={1} />
            <p className="text-sm tracking-[0.2em] uppercase">Empty</p>
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

// --- MAIN APP ---
const App = () => {
  const [currentView, setCurrentView] = useState('home');
  const [selectedMaster, setSelectedMaster] = useState<any>(null);
  const [isLoginOpen, setLoginOpen] = useState(false);
  const [isCartOpen, setCartOpen] = useState(false);

  return (
    <div className="bg-black min-h-screen" style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>
      <NavBar 
        setView={setCurrentView} 
        openCart={() => setCartOpen(true)}
        openLogin={() => setLoginOpen(true)}
      />

      <LoginModal isOpen={isLoginOpen} onClose={() => setLoginOpen(false)} />
      <CartDrawer isOpen={isCartOpen} onClose={() => setCartOpen(false)} />

      <main>
        {currentView === 'home' && <Hero setView={setCurrentView} />}
        {currentView === 'portal' && <PortalView setMaster={setSelectedMaster} />}
        {currentView === 'client-form' && <ClientForm onClose={() => setCurrentView('home')} />}
        {currentView === 'artist-form' && <ArtistForm onClose={() => setCurrentView('home')} />}
      </main>

      <AnimatePresence>
        {selectedMaster && (
          <MasterDetail 
            master={selectedMaster} 
            onClose={() => setSelectedMaster(null)} 
            onHire={() => {
              setSelectedMaster(null);
              setCurrentView('client-form');
            }} 
          />
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="bg-black border-t-2 border-white/10 py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-20 mb-20">
            <div>
              <div className="w-40 mb-8">
                <BoyinwinLogo white />
              </div>
              <p className="text-sm text-white/40 leading-relaxed tracking-wide">
                A Himalayan vineyard of talent, cultivated at altitude.
              </p>
            </div>
            
            <div>
              <h4 className="text-xs tracking-[0.3em] text-white/40 uppercase mb-8">Vintages</h4>
              <div className="space-y-4 text-sm text-white/60">
                {GENRES.slice(0, 5).map(g => <div key={g.name} className="hover:text-white transition-colors cursor-pointer tracking-wide">{g.name}</div>)}
              </div>
            </div>
            
            <div>
              <h4 className="text-xs tracking-[0.3em] text-white/40 uppercase mb-8">Services</h4>
              <div className="space-y-4 text-sm text-white/60">
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Reservations</div>
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Subscriptions</div>
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Marketplace</div>
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Join</div>
              </div>
            </div>
            
            <div>
              <h4 className="text-xs tracking-[0.3em] text-white/40 uppercase mb-8">Vineyard</h4>
              <div className="space-y-4 text-sm text-white/60">
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Philosophy</div>
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Location</div>
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Contact</div>
                <div className="hover:text-white transition-colors cursor-pointer tracking-wide">Careers</div>
              </div>
            </div>
          </div>
          
          <div className="border-t-2 border-white/10 pt-12 flex flex-col md:flex-row justify-between items-center">
            <p className="text-xs text-white/30 tracking-[0.3em] uppercase">© 2024 Boyinwin Vineyard</p>
            <div className="flex gap-12 mt-6 md:mt-0 text-xs text-white/30 tracking-wide">
              <a href="#" className="hover:text-white transition-colors uppercase">Privacy</a>
              <a href="#" className="hover:text-white transition-colors uppercase">Terms</a>
              <a href="#" className="hover:text-white transition-colors uppercase">Legal</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;